package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import module_three_milestone.Contact;

class ContactTest {

	@Test
	void ContactClassTest() {
		Contact contact = new Contact("Danny", "Faught", "8888888888", "420 Doobie Lane");
		Assertions.assertAll("check lengths correct", 
				() -> assertEquals(contact.getContactId().length() <= 10, true),
				() -> assertEquals(contact.getFirstName().length() <= 10, true),
				() -> assertEquals(contact.getLastName().length() <= 10, true),
				() -> assertEquals(contact.getPhoneNumber().length() == 10, true),
				() -> assertEquals(contact.getAddress().length() <= 30, true));
	}
	
	@Test
	void InvalidContactTest() {
		Assertions.assertAll("check invalid initial fields",
				() -> assertThrows(IllegalArgumentException.class, 
						() -> {new Contact("Supercalifragilistic", "Faught", "8888888888", "420 Doobie Lane");}
					),
				() -> assertThrows(IllegalArgumentException.class, 
						() -> {new Contact("Danny", "Expialidocious", "8888888888", "420 Doobie Lane");}
					),
				() -> assertThrows(IllegalArgumentException.class, 
						() -> {new Contact("Danny", "Faught", "9", "420 Doobie Lane");}
					),
				() -> assertThrows(IllegalArgumentException.class, 
						() -> {new Contact("Danny", "Faught", "8888888888", "Pneumonoultramicroscopicsilicovolcanoconiosis");}
					),
				() -> assertThrows(IllegalArgumentException.class, 
						() -> {new Contact(null, "Faught", "8888888888", "Pneumonoultramicroscopicsilicovolcanoconiosis");}
					),
				() -> assertThrows(IllegalArgumentException.class, 
						() -> {new Contact("Danny", null, "8888888888", "Pneumonoultramicroscopicsilicovolcanoconiosis");}
					),
				() -> assertThrows(IllegalArgumentException.class, 
						() -> {new Contact("Danny", "Faught", null, "Pneumonoultramicroscopicsilicovolcanoconiosis");}
					),
				() -> assertThrows(IllegalArgumentException.class, 
						() -> {new Contact("Danny", "Faught", "8888888888", null);}
					),
				() -> assertThrows(IllegalArgumentException.class, 
						() -> {new Contact("Danny", "Faught", "99999999991", "420 Doobie Lane");}
					)
				);
	}

}
