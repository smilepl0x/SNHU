package module_three_milestone;

public class Contact {
	private String contactId;
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String address;
	
	public boolean validate(String string, int length, boolean exact) {
		if (string == null) {
			return false;
		}
		
		if (!exact) {
			if(string.length() > length) {
				return false;
			}
		}
		else {
			if (string.length() != length) {
				return false;
			}
		}
		
		return true;
	}
	
	
	public Contact(String firstName, String lastName, String phoneNumber, String address){
		if (!validate(firstName, 10, false)) {
			throw new IllegalArgumentException("Invalid first name");
		}
		if (!validate(lastName, 10, false)) {
			throw new IllegalArgumentException("Invalid last name");
		}
		if (!validate(phoneNumber, 10, true)) {
			throw new IllegalArgumentException("Invalid phone number");
		}
		if (!validate(address, 30, false)) {
			throw new IllegalArgumentException("Invalid address");
		}
		
		this.contactId = phoneNumber;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.address = address;
	}
	
	public String getContactId() {
		return this.contactId;
	}
	
	public String getFirstName() {
		return this.firstName;
	}
	
	public String getLastName() {
		return this.lastName;
	}
	
	public String getPhoneNumber() {
		return this.phoneNumber;
	}
	
	public String getAddress() {
		return this.address;
	}
	
	public void setFirstName(String firstName) {
		if (!validate(firstName, 10, false)) {
			throw new IllegalArgumentException("Invalid first name");
		}
		this.firstName = firstName;
	}
	
	public void setLastName(String lastName) {
		if (!validate(lastName, 10, false)) {
			throw new IllegalArgumentException("Invalid last name");
		}
		this.lastName = lastName;
	}
	
	public void setPhoneNumber(String phoneNumber) {
		if (!validate(phoneNumber, 10, true)) {
			throw new IllegalArgumentException("Invalid phone number");
		}
		this.phoneNumber = phoneNumber;
	}
	
	public void setAddress (String address) {
		if (!validate(address, 30, false)) {
			throw new IllegalArgumentException("Invalid address");
		}
		this.address = address;
	}
}
