package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import module_three_milestone.ContactService;

class ContactServiceTest {

	@Test
	void ContactServiceMethodTest() {
		ContactService contactService = new ContactService();
		Assertions.assertEquals(contactService.getAllContacts().isEmpty(), true);
		
		contactService.createContact("Danny", "Faught", "8888888888", "420 Doobie Lane");
		Assertions.assertEquals(contactService.getAllContacts().isEmpty(), false);
		
		contactService.updateContact("8888888888", "Poopoo", "Peepee", "9999999999", "Hi mom");
		Assertions.assertAll(
				() -> assertEquals(contactService.getContactById("8888888888").getFirstName(), "Poopoo"),
				() -> assertEquals(contactService.getContactById("8888888888").getLastName(), "Peepee"),
				() -> assertEquals(contactService.getContactById("8888888888").getPhoneNumber(), "9999999999"),
				() -> assertEquals(contactService.getContactById("8888888888").getAddress(), "Hi mom")
			);
		
		contactService.removeContact("8888888888");
		Assertions.assertEquals(contactService.getAllContacts().isEmpty(), true);
	}

}
