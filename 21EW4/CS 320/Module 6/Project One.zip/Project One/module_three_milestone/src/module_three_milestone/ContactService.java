package module_three_milestone;
import java.util.ArrayList;

public class ContactService {
	ArrayList<Contact> contacts = new ArrayList<Contact>();
	
	public Contact getContactById(String id) {
		for (Contact contact : contacts) {
			if (contact.getContactId().equals(id)) {
				return contact;
			}
		}
		return null;
	}
	
	public void createContact(String firstName, String lastName, String phoneNumber, String address) {
		Contact contact = new Contact(firstName, lastName, phoneNumber, address);
		if (getContactById(phoneNumber) == null) {
			contacts.add(contact);
		}
		else {
			throw new IllegalArgumentException("That contact already exists!");
		}
	}
	
	public void removeContact(String id) {
		Contact removingContact = getContactById(id);
		if (removingContact != null) {
			contacts.remove(removingContact);
		}
		else {
			throw new IllegalArgumentException("That contact doesn't exist!");
		}
	}
	
	public void updateContact(String id, String firstName, String lastName, String phoneNumber, String address) {
		Contact editingContact = getContactById(id);
		if (editingContact != null) {
			editingContact.setFirstName(firstName);
			editingContact.setLastName(lastName);
			editingContact.setPhoneNumber(phoneNumber);
			editingContact.setAddress(address);
		}
		else {
			throw new IllegalArgumentException("That contact doesn't exist!");
		}
	}
	
	public ArrayList<Contact> getAllContacts() {
		return contacts;
	}
}
