package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import appointment.AppointmentService;
import appointment.Appointment;

class AppointmentServiceTest {	
	long millisec = 1000000000;
	Date goodDate = new Date(System.currentTimeMillis() + millisec);
	Date badDate = new Date(System.currentTimeMillis() - millisec); // date in past
	String goodDesc = "Need to go to the dr. today";
	String badDesc = "Need to go to the dr. today about that... thing. People are asking questions.";
	
	AppointmentService testService = new AppointmentService();
	
	@Test
	void test_addAppointment() {		
		testService.addAppointment(goodDate, goodDesc);
		Assertions.assertAll("", () -> {
			assertNotNull(testService.appointments);
		});
	}

	@Test
	void test_deleteAppointment() {
		testService.addAppointment(goodDate, goodDesc);
		String deletingAppointmentId = testService.appointments.get(0).getId();
		Assertions.assertAll("", () -> {
			testService.deleteAppointment(deletingAppointmentId);
			assertTrue(testService.appointments.isEmpty());
		},
		() -> 
			assertThrows(IllegalArgumentException.class, () -> {testService.deleteAppointment("1");})
		);
	}
}
