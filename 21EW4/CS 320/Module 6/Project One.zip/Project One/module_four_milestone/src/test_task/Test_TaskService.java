package test_task;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import task.TaskService;

class Test_TaskService {

	@Test
	void TestTaskService() {
		TaskService taskService = new TaskService();
		Assertions.assertTrue(taskService.getAllTasks().isEmpty());
		
		taskService.createTask("Buy Groceries", "Remove bum from sofa, drive to store.");
		Assertions.assertFalse(taskService.getAllTasks().isEmpty());		
		
		String taskIdFirstElement = taskService.getAllTasks().get(0).getTaskId();
		
		// First add
		Assertions.assertAll(
				() -> assertEquals("Buy Groceries", taskService.getTaskById(taskIdFirstElement).getName()),
				() -> assertEquals("Remove bum from sofa, drive to store.", taskService.getTaskById(taskIdFirstElement).getDescription())
		);
		
		Assertions.assertEquals(taskService.getAllTasks().get(0), taskService.getTaskById(taskIdFirstElement));
		
		// After updating
		taskService.updateTask(taskIdFirstElement, "Be nice", "You should really be nicer to yourself, man.");
		Assertions.assertAll(
				() -> assertFalse(taskService.getAllTasks().isEmpty()),
				() -> assertEquals("Be nice", taskService.getTaskById(taskIdFirstElement).getName()),
				() -> assertEquals("You should really be nicer to yourself, man.", taskService.getTaskById(taskIdFirstElement).getDescription()),
				() -> assertThrows(IllegalArgumentException.class,
						() -> {taskService.updateTask(null, null, null);}
						)
		);
		
		// Removing
		taskService.removeTask(taskIdFirstElement);
		Assertions.assertAll(
				() -> assertEquals(taskService.getAllTasks().isEmpty(), true),
				() -> assertThrows(IllegalArgumentException.class,
						() -> {taskService.removeTask(null);}
						)
		);
	}

}
