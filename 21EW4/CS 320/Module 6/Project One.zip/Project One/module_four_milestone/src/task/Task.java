package task;
import java.lang.Math;

public class Task {
	private String taskId;
	private String name;
	private String description;
	
	private boolean validate(String string, int maxLength) {
		if (string == null || string.length() > maxLength) {
			return false;
		}
		
		return true;
	}
	
	
	public Task(String name, String description){
		if (!validate(name, 20)) {
			throw new IllegalArgumentException("Invalid name");
		}
		if (!validate(description, 50)) {
			throw new IllegalArgumentException("Invalid description");
		}
		
		// Create random 10 character ID
		this.taskId = String.valueOf((int)(Math.random() * (99999999 - 10000000 + 1) + 10000000)) + name.substring(0, 1) + description.substring(0, 1);
		this.name = name;
		this.description = description;
	}
	
	public String getTaskId() {
		return this.taskId;
	}
	
	public String getName() {
		return this.name;
	}
	
	public String getDescription() {
		return this.description;
	}
	
	public void setName(String name) {
		if (!validate(name, 20)) {
			throw new IllegalArgumentException("Invalid first name");
		}
		this.name = name;
	}
	
	public void setDescription(String description) {
		if (!validate(description, 50)) {
			throw new IllegalArgumentException("Invalid description");
		}
		this.description = description;
	}
}
