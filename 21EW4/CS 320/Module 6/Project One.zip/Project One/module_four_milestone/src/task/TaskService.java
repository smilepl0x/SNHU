package task;
import java.util.ArrayList;

import task.Task;

public class TaskService {
	ArrayList<Task> tasks = new ArrayList<Task>();
	
	public Task getTaskById(String id) {
		for (Task task : tasks) {
			if (task.getTaskId().equals(id)) {
				return task;
			}
		}
		return null;
	}
	
	public void createTask(String name, String description) {
		Task task = new Task(name, description);
		if (getTaskById(task.getTaskId()) == null) {
			tasks.add(task);
		}
		else {
			throw new IllegalArgumentException("That task already exists!");
		}
	}
	
	public void removeTask(String id) {
		Task removingTask = getTaskById(id);
		if (removingTask != null) {
			tasks.remove(removingTask);
		}
		else {
			throw new IllegalArgumentException("That task doesn't exist!");
		}
	}
	
	public void updateTask(String id, String name, String description) {
		Task editingTask = getTaskById(id);
		if (editingTask != null) {
			editingTask.setName(name);
			editingTask.setDescription(description);
		}
		else {
			throw new IllegalArgumentException("That task doesn't exist!");
		}
	}
	
	public ArrayList<Task> getAllTasks() {
		return tasks;
	}
}
