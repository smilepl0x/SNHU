package test_task;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import task.Task;

class Test_Task {

	@Test
	void TestTask() {
		Task task = new Task("Buy Groceries", "Remove bum from sofa, drive to store.");
		Assertions.assertAll("check lengths correct", 
				() -> assertTrue(task.getTaskId().length() == 10 && task.getTaskId() != null),
				() -> assertTrue(task.getName().length() <= 20 && task.getName() != null),
				() -> assertTrue(task.getDescription().length() <= 50 && task.getDescription() != null)
		);
		
		Assertions.assertAll("check invalid initial fields",
				() -> assertThrows(IllegalArgumentException.class, 
						() -> {new Task("Get up, buy groceries, come home, sit down.", "Remove bum from sofa, drive to store.");}
					),
				() -> assertThrows(IllegalArgumentException.class, 
						() -> {new Task("Buy Groceries", "Remove bum from sofa, place bum in car, drive to store, find stuff, come home.");}
					),
				() -> assertThrows(IllegalArgumentException.class,
						() -> {new Task(null, null);}
					)
		);
	}
	
	@Test
	void TestSetters() {
		Task task = new Task("Buy Groceries", "Remove bum from sofa, drive to store.");
		task.setName("Buy Beer");
		task.setDescription("Call your mom afterwards.");
		
		Assertions.assertAll("check setters",
			() -> assertEquals("Buy Beer", task.getName()),
			() -> assertThrows(IllegalArgumentException.class,
					() -> {task.setName("Buy beer and then develop a problem and lose all your friends");}
				),
			
			() -> assertEquals("Call your mom afterwards.", task.getDescription()),
			() -> assertThrows(IllegalArgumentException.class,
					() -> {task.setDescription("Call your mom afterwards and cry to her about how you don't understand how you got here");}
				)
		);
		
	}

}
