package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import appointment.Appointment;

class AppointmentTest {
	
	long millisec = 1000000000;
	Date goodDate = new Date(System.currentTimeMillis() + millisec);
	Date badDate = new Date(System.currentTimeMillis() - millisec); // date in past
	String goodDesc = "Need to go to the dr. today";
	String badDesc = "Need to go to the dr. today about that... thing. People are asking questions.";

	@Test
	void test_Appointment() {
		Appointment testAppointment = new Appointment(goodDate, "Need to go to the dr. today");
		Assertions.assertNotNull(testAppointment);
	}
	
	@Test
	void test_BadAppointment() {
		Assertions.assertAll("check bad params",
			() -> assertThrows(IllegalArgumentException.class,
					() -> {new Appointment(badDate, goodDesc);}
			),
			() -> assertThrows(IllegalArgumentException.class,
					() -> {new Appointment(goodDate, badDesc);}
			),
			() -> assertThrows(IllegalArgumentException.class,
					() -> {new Appointment(null, badDesc);}
			),
			() -> assertThrows(IllegalArgumentException.class,
					() -> {new Appointment(goodDate, null);}
			)
		);
	}
	
	@Test
	void test_getId() {
		Appointment testAppointment = new Appointment(goodDate, goodDesc);
		Assertions.assertNotNull(testAppointment.getId());
	}

}
