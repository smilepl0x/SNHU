package appointment;
import java.util.ArrayList;
import java.util.Date;

import appointment.Appointment;

public class AppointmentService {
	public ArrayList<Appointment> appointments = new ArrayList<Appointment>();
	
	public Appointment getAppointmentById(String id) {
		for (Appointment appointment : appointments) {
			if (appointment.getId().equals(id)) {
				return appointment;
			}
		}
		return null;
	}
	
	public void addAppointment(Date date, String description) {
		Appointment addingAppointment = new Appointment(date, description);
		if (getAppointmentById(addingAppointment.getId())== null) {
			appointments.add(addingAppointment);
		}
		else {
			throw new IllegalArgumentException("That appointment already exists!");
		}
	}
	
	public void deleteAppointment(String id) {
		Appointment removingAppointment = getAppointmentById(id);
		if (removingAppointment != null) {
			appointments.remove(removingAppointment);
		}
		else {
			throw new IllegalArgumentException("That appointment doesn't exist!");
		}
	}

}
