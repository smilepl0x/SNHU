package appointment;

import java.util.Date;

public class Appointment {
	private String id;
	private Date date;
	private String description;
	
	private boolean validate(String string, int maxLength) {
		if (string == null || string.length() > maxLength) {
			return false;
		}
		
		return true;
	}
	
	public Appointment (Date date, String description) {
		if (!validate(description, 50)) {
			throw new IllegalArgumentException("Invalid description");
		}
		
		if (date.before(new Date())) {
			throw new IllegalArgumentException("Invalid date");
		}
		
		// Create random 10 char id
		this.id = String.valueOf((int)(Math.random() * (99999999 - 10000000 + 1) + 10000000)) + description.substring(0, 2);
		this.description = description;
	}
	
	public String getId() {
		return this.id;
	}
}
