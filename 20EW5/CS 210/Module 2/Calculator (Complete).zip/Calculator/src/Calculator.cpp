/*
 * Calculator.cpp
 *
 *  Date: [Enter date]
 *  Author: [Your Name]
 */

#include <iostream>
using namespace std; // Added

int main() // Changed return type
{
	// char statement[100]; unused. removed
	double op1, op2;
	char operation;
	char answer = 'Y'; // Added spaces and semi-colon and ' instead of "
	while (answer == 'y' || answer == 'Y') // Added conditional
	{
		cout << "Enter expression" << endl; // Spaces for clarity
		cin >> op1 >> operation >> op2; // switched op1 & 2 for user clarity
		if (operation == '+') // ' instead of ", added brackets
		{
			cout << op1 << " + " << op2 << " = " << op1 + op2 << endl; // << instead of >>
		}
		if (operation == '-') // brackets, <<
		{
			cout << op1 << " - " << op2 << " = " << op1 - op2 << endl;
		}
		if (operation == '*') // brackets, semi-colon, corrected operation
		{
			cout << op1 << " * " << op2 << " = " << op1 * op2 << endl;
		}
		if (operation == '/') // brackets, corrected operation
		{
			cout << op1 << " / " << op2 << " = " << op1 / op2 << endl;
		}

		cout << "Do you wish to evaluate another expression? " << endl;
		cin >> answer;
	}

	cout << "Program finished."; // Added message
	return 0; // Added return statement
}







