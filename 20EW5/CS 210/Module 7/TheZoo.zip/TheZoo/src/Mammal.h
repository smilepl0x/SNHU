/*
 * Mammal.h
 *
 *  Created on: Jun 16, 2020
 *      Author: Danny Faught
 */

#ifndef MAMMAL_H_
#define MAMMAL_H_

#include "Animal.h"

class Mammal: public Animal {
public:
	int nurse;
	std::string type;
	Mammal();
};

#endif /* MAMMAL_H_ */
