/*
 * Bat.h
 *
 *  Created on: Jun 16, 2020
 *      Author: 1504405_snhu
 */

#ifndef BAT_H_
#define BAT_H_

#include "Mammal.h"

class Bat: public Mammal {
public:
	std::string subType;
	Bat();
};

#endif /* BAT_H_ */
