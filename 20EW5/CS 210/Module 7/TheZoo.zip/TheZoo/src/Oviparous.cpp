/*
 * Oviparous.cpp
 *
 *  Created on: Jun 16, 2020
 *      Author: Danny Faught
 */
#include "Oviparous.h"

Oviparous::Oviparous(std::string name, int trackNum, int numEggs): Animal(name, trackNum) {
		this->numEggs = numEggs;
		type = "Oviparous";
}

Oviparous::~Oviparous(){}

void Oviparous::Print() {
	std::cout << type << " " << numEggs;
}


