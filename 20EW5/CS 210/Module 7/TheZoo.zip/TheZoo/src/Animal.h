/*
 * Animal.h
 *
 *  Created on: Jun 16, 2020
 *      Author: Danny Faught
 */

#ifndef ANIMAL_H_
#define ANIMAL_H_

#include <iostream>
#include <string>

class Animal {
public:
	std::string name;
	int trackNum;
	Animal();
	Animal(std::string name, int trackNum);
	virtual ~Animal();
	virtual void Print();
	virtual void PrintToFile(std::string fileName);
};

#endif /* ANIMAL_H_ */
