/*
 * Pelican.cpp
 *
 *  Created on: Jun 16, 2020
 *      Author: Danny Faught
 */
#include "Pelican.h"

Pelican::Pelican(){ subType = "Pelican"; }




