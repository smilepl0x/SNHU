/*
 * Goose.cpp
 *
 *  Created on: Jun 16, 2020
 *      Author: Danny Faught
 */
#include "Goose.h"

Goose::Goose(){ subType = "Goose"; }




