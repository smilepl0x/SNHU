/*
 * Crocodile.cpp
 *
 *  Created on: Jun 16, 2020
 *      Author: Danny Faught
 */

#include "Crocodile.h"

Crocodile::Crocodile(std::string name, int trackNum, int numEggs): Oviparous(name, trackNum, numEggs){ subType = "Crocodile"; }

void Crocodile::Print() {
	std::cout << name << " " << trackNum << " " << type << " " << subType << " " << numEggs;
}



