/*
 * Oviparous.h
 *
 *  Created on: Jun 16, 2020
 *      Author: Danny Faught
 */

#ifndef OVIPAROUS_H_
#define OVIPAROUS_H_

#include <iostream>
#include "Animal.h"

class Oviparous: public Animal {
public:
	int numEggs = -1;
	std::string type;
	Oviparous();
	Oviparous(std::string, int trackNum, int numEggs);
	virtual ~Oviparous();
	virtual void Print();
	virtual void PrintToFile(std::string fileName);
};

#endif /* OVIPAROUS_H_ */
