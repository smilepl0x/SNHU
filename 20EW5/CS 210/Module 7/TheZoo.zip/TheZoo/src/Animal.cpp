/*
 * Animal.cpp
 *
 *  Created on: Jun 16, 2020
 *      Author: Danny Faught
 */
#include "Animal.h"

Animal::Animal(std::string name, int trackNum) {
		this->name = name;
		this->trackNum = trackNum;
}

Animal::~Animal() {}




