/*
 * SeaLion.cpp
 *
 *  Created on: Jun 16, 2020
 *      Author: Danny Faught
 */
#include "SeaLion.h"

SeaLion::SeaLion(){ subType = "SeaLion"; }




