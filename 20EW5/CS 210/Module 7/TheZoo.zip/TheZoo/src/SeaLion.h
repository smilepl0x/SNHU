/*
 * SeaLion.h
 *
 *  Created on: Jun 16, 2020
 *      Author: Danny Faught
 */

#ifndef SEALION_H_
#define SEALION_H_

#include "Mammal.h"

class SeaLion: public Mammal {
public:
	std::string subType;
	SeaLion();
};

#endif /* SEALION_H_ */
