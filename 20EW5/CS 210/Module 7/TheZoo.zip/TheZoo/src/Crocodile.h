/*
+ * Crocodile.h
 *
 *  Created on: Jun 16, 2020
 *      Author: Danny Faught
 */

#ifndef CROCODILE_H_
#define CROCODILE_H_

#include <iostream>
#include "Oviparous.h"

class Crocodile: public Oviparous {
public:
	std::string subType;
	Crocodile();
	Crocodile(std::string name, int trackNum, int numEggs);
	void Print();
	void PrintToFile(std::string fileName);
};

#endif /* CROCODILE_H_ */
