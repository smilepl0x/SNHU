/*
 * Mammal.cpp
 *
 *  Created on: Jun 16, 2020
 *      Author: Danny Faught
 */
#include "Mammal.h"

Mammal::Mammal() {
		nurse = 0;
		type = "Mammal";
}




