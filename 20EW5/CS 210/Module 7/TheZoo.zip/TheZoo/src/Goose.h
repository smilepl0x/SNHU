/*
 * Goose.h
 *
 *  Created on: Jun 16, 2020
 *      Author: Danny Faught
 */

#ifndef GOOSE_H_
#define GOOSE_H_

#include "Oviparous.h"

class Goose: public Oviparous {
public:
	std::string subType;
	Goose();
};

#endif /* GOOSE_H_ */
