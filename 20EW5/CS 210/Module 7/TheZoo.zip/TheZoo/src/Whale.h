/*
 * Whale.h
 *
 *  Created on: Jun 16, 2020
 *      Author: Danny Faught
 */

#ifndef WHALE_H_
#define WHALE_H_

#include "Mammal.h"

class Whale: public Mammal {
public:
	std::string subType;
	Whale();
};

#endif /* WHALE_H_ */
