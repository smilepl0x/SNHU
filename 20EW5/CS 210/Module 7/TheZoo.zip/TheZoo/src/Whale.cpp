/*
 * Whale.cpp
 *
 *  Created on: Jun 16, 2020
 *      Author: Danny Faught
 */
#include "Whale.h"

Whale::Whale(){ subType = "Whale"; }



