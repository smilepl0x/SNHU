/*
 * Pelican.h
 *
 *  Created on: Jun 16, 2020
 *      Author: Danny Faught
 */

#ifndef PELICAN_H_
#define PELICAN_H_

#include "Oviparous.h"

class Pelican: public Oviparous {
public:
	std::string subType;
	Pelican();
};

#endif /* PELICAN_H_ */
