/*
 * Bat.cpp
 *
 *  Created on: Jun 16, 2020
 *      Author: Danny Faught
 */
#include "Bat.h"

Bat::Bat(){ subType = "Bat"; }




