#include <iostream>
#include <jni.h>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>

// TODO: Generate .h files
#include "Crocodile.h"
#include "Goose.h"
#include "Pelican.h"
#include "Bat.h"
#include "Whale.h"
#include "SeaLion.h"


using namespace std;

void GenerateData()               //DO NOT TOUCH CODE IN THIS METHOD
{
     JavaVM *jvm;                      // Pointer to the JVM (Java Virtual Machine)
     JNIEnv *env;                      // Pointer to native interface
                                                              //================== prepare loading of Java VM ============================
     JavaVMInitArgs vm_args;                        // Initialization arguments
     JavaVMOption* options = new JavaVMOption[1];   // JVM invocation options
     options[0].optionString = (char*) "-Djava.class.path=";   // where to find java .class
     vm_args.version = JNI_VERSION_1_6;             // minimum Java version
     vm_args.nOptions = 1;                          // number of options
     vm_args.options = options;
     vm_args.ignoreUnrecognized = false;     // invalid options make the JVM init fail
                                                                          //=============== load and initialize Java VM and JNI interface =============
     jint rc = JNI_CreateJavaVM(&jvm, (void**)&env, &vm_args);  // YES !!
     delete options;    // we then no longer need the initialisation options.
     if (rc != JNI_OK) {
            // TO DO: error processing...
            cin.get();
            exit(EXIT_FAILURE);
     }
     //=============== Display JVM version =======================================
     cout << "JVM load succeeded: Version ";
     jint ver = env->GetVersion();
     cout << ((ver >> 16) & 0x0f) << "." << (ver & 0x0f) << endl;

     jclass cls2 = env->FindClass("ZooFileWriter");  // try to find the class
     if (cls2 == nullptr) {
            cerr << "ERROR: class not found !";
     }
     else {                                  // if class found, continue
            cout << "Class MyTest found" << endl;
            jmethodID mid = env->GetStaticMethodID(cls2, "createZooFile", "()V");  // find method
            if (mid == nullptr)
                   cerr << "ERROR: method void createZooFile() not found !" << endl;
            else {
                   env->CallStaticVoidMethod(cls2, mid);                      // call method
                   cout << endl;
            }
     }


     jvm->DestroyJavaVM();
     cin.get();
}

Animal AddAnimal()
{
     /*
            TODO: Write proper code to add an animal to your vector (or array)
     */

	//Instance variables
	int userTrackNum;
	string userName;
	string userType;
	string userSubType;
	int userNumEggs;
	int userNurse = 0;
	int userInput;

	// Get tracking number
	do {
		cout << "Please enter the tracking number of your animal (up to 6 digits)" << endl;
		cin >> userTrackNum;
		if (cin.fail()) {
			cout << "Please enter a valid number" << endl;
			userTrackNum = 0;
		}
	}
	while(userTrackNum > 99999 || userTrackNum <= 0);

	// Get name
	do {
		cout << "Please enter the name of the animal (Up to 15 characters)" << endl;
		cin >> userName;
		if (cin.fail()) {
			cout << "Please enter a valid name" << endl;
		}
	}
	while (userName.length() > 15);

	// Get sub-type
	do {
		cout << "Please select a subtype for your animal" << endl
				<< "1. Crocodile" << endl
				<< "2. Goose" << endl
				<< "3. Pelican" << endl
				<< "4. Bat" << endl
				<< "5. Whale" << endl
				<< "6. SeaLion" << endl;;
		cin >> userInput;
		if (cin.fail()) {
			cout << "Please enter a valid selection" << endl;
			userInput = 0;
		}
	}
	while(userInput <= 0 || userInput > 6);

	switch (userInput) {
	case 1:
	{
		do {
			cout << "How many eggs is this animal carrying?" << endl;
			cin >> userNumEggs;
			if (cin.fail()) {
				cout << "Please enter a valid number" <<endl;
				userNumEggs = -1;
			}
		}
		while (userNumEggs < 0);

		return Crocodile(userName, userTrackNum, userNumEggs);
	}
	}

	return Animal("none", 1);

}


void RemoveAnimal()
{
     /*
            TODO: Write proper code to remove an animal from your vector (or array. Remmber to re-allocate proper size if using array)
     */
}

//Animal* LoadDataFromFile()
//{
//     /*
//            TODO: Write proper code to load data from input file (generated using JNI) into vector/array.
//     */
//	// Initialize pointers
////	Goose* goosePtr;
////	Pelican* pelicanPtr;
////	Bat* batPtr;
////	Whale* whalePtr;
////	SeaLion* seaLionPtr;
//
//	// Open file
//
//	string line;
//	string skip;
//	ifstream inFile;
//	inFile.open("zoodata.txt");
//	if (!inFile) {
//	    cerr << "Unable to open file zoodata.txt";
//	    exit(1);   // call system to stop
//	}
//	else {
//		cout << "File Opened" << endl;
//	}
//
//	// For each line in file, check for sub-type and cast animalPtr object into correct type
//	while (getline(inFile, line)) {
//		// Look for animals
//		//size_t found = line.find("Crocodile");
//		if (line.find("Crocodile") != string::npos) {
//			Crocodile* crocodile = new Crocodile();
//			istringstream iss(line);
//			iss >> crocodile->trackNum;
//			iss >> crocodile->name;
//			iss >> crocodile->type;
//			iss >> crocodile->subType;
//			iss >> crocodile->numEggs;
//			iss >> skip;
//
//			return crocodile;
//		}
//	}
//
//
//	return new Animal;
//
//}

void SaveDataToFile()
{
     /*
            TODO: Write proper code to store vector/array to file.
     */
}

int DisplayMenu()
{
	int userInput;
	try {
		cout << "Please choose from the following:" << endl
				<< "1. Load Animal Data" << endl
				<< "2. Generate Data" << endl
				<< "3. Display Animal Data" << endl
				<< "4. Add record" << endl
				<< "5. Delete Record" << endl
				<< "6. Save Animal Data" << endl
				<< "9. Exit" << endl;
		cin >> userInput;
		if (cin.fail()) {
			throw "Error";
		}
	}
	catch (...) {
		cout << "Please restart the program and enter valid selection." << endl;
	}

	return userInput;
}



int main()
{
	vector<Animal> animals;

	bool keepGoing = true;

	while (keepGoing == true) {
		switch (DisplayMenu()) {
		case 1:
			//animals.push_back(*LoadDataFromFile());
			for (unsigned int i = 0; i < animals.size(); i++) {
				animals.at(i).Print();
			}
			break;
		case 2:
			GenerateData();
			break;
		case 3:
			//DisplayAnimalData();
			break;
		case 4:
		{
			animals.push_back(AddAnimal());

			for (unsigned int i = 0; i < animals.size(); i++) {
				animals[i].Print();
			}
			break;
		}
		case 5:
			RemoveAnimal();
			break;
		case 6:
			SaveDataToFile();
			break;
		case 9:
			keepGoing = false;
			cout << "Goodbye" << endl;
			break;
		default:
			return 1;
			break;
		}
	}
	return 1;
}
